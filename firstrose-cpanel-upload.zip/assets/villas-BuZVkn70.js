import{j as t,O as o}from"./index-DGR86JMh.js";const n=()=>t.jsx(o,{});export{n as component};
